{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script> --}}
<script src="{{ url('') }}/assets/js/feather-icons/feather.min.js"></script>
<script src="{{ url('') }}/assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="{{ url('') }}/assets/js/app.js"></script>

<script src="{{ url('') }}/assets/vendors/chartjs/Chart.min.js"></script>

<script src="{{ url('') }}/assets/js/pages/dashboard.js"></script>

<script src="{{ url('') }}/assets/js/main.js"></script>


<div id="sidebar" class='active'>
    <div class="sidebar-wrapper active">
        <div class="sidebar-header">
            
            <h2 class="fw-bolder">SIPANDU</h2>
        </div>
        <div class="sidebar-menu">
            <ul class="menu">
                <li class="sidebar-title">Main Menu</li>
                <li class="sidebar-item active ">
                    <a href="<?php echo e(route('dashboard')); ?>" class="sidebar-link">
                        <i class="fa-solid fa-house"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <?php if(in_array(session()->get('role'), ['A', 'P'])): ?>
                    <li class="sidebar-item  has-sub">
                        <a href="#" class="sidebar-link">
                            <i class="fa-solid fa-server"></i>
                            <span>Data Master</span>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="<?php echo e(route('master-ibu')); ?>" class="ps-4">
                                    <i class="fa-solid fa-circle-dot fa-sm me-1"></i>
                                    <span>Data Ibu</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('master-anak')); ?>" class="ps-4">
                                    <i class="fa-solid fa-circle-dot fa-sm me-1"></i>
                                    <span>Data Anak</span>
                                </a>
                            </li>
                            <?php if(in_array(session()->get('role'), ['A'])): ?>
                                <li>
                                    <a href="<?php echo e(route('master-posyandu')); ?>" class="ps-4">
                                        <i class="fa-solid fa-circle-dot fa-sm me-1"></i>
                                        <span>Data Posyandu</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('master-jenis-vitamin')); ?>" class="ps-4">
                                        <i class="fa-solid fa-circle-dot fa-sm me-1"></i>
                                        <span>Data Jenis Vitamin</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('master-jenis-imunisasi')); ?>" class="ps-4">
                                        <i class="fa-solid fa-circle-dot fa-sm me-1"></i>
                                        <span>Data Jenis Imunisasi</span>
                                    </a>
                                </li>
                            <?php endif; ?>

                        </ul>

                    </li>
                <?php endif; ?>
                <?php if(in_array(session()->get('role'), ['A', 'O'])): ?>
                    <?php if(in_array(session()->get('role'), ['A'])): ?>
                        <li class="sidebar-item ">
                            <a href="<?php echo e(route('master-check-imunisasi')); ?>" class="sidebar-link">
                                <i class="fa-solid fa-syringe"></i>
                                <span>Data Imunisasi</span>
                            </a>
                        </li>
                        <li class="sidebar-item ">
                            <a href="<?php echo e(route('master-check-vitamin')); ?>" class="sidebar-link">
                                <i class="fa-solid fa-pills"></i>
                                <span>Data Vitamain</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <li class="sidebar-item ">
                        <a href="<?php echo e(route('master-jadwal-posyandu')); ?>" class="sidebar-link">
                            <i class="fa-solid fa-calendar-days"></i>
                            <span>Jadwal Posyandu</span>
                        </a>
                    </li>
                <?php endif; ?>

                <li class="sidebar-item ">
                    <a href="<?php echo e(route('master-check-up')); ?>" class="sidebar-link">
                        <i class="fa-solid fa-stethoscope"></i>
                        <span>Check UP</span>
                    </a>
                </li>
            </ul>
        </div>
        <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
    </div>
</div>
<?php /**PATH C:\laragon\www\app-posyandu\resources\views/_partials/sidebar.blade.php ENDPATH**/ ?>
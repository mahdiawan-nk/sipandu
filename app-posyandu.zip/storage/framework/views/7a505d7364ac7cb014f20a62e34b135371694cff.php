
<script src="<?php echo e(url('')); ?>/assets/js/feather-icons/feather.min.js"></script>
<script src="<?php echo e(url('')); ?>/assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="<?php echo e(url('')); ?>/assets/js/app.js"></script>

<script src="<?php echo e(url('')); ?>/assets/vendors/chartjs/Chart.min.js"></script>

<script src="<?php echo e(url('')); ?>/assets/js/pages/dashboard.js"></script>

<script src="<?php echo e(url('')); ?>/assets/js/main.js"></script>

<?php /**PATH C:\laragon\www\app-posyandu\resources\views/_partials/script.blade.php ENDPATH**/ ?>